var menuState = document.getElementsByTagName("body")[0];
var screenWidth = window.innerWidth;
if(screenWidth < 1024) {
    menuState.classList.add('compact-menu-state');
}

const tabs = document.querySelectorAll("[data-tab-target]")
const tabContents = document.querySelectorAll('[data-tab-content]');
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = document.querySelector(tab.dataset.tabTarget);
        tabContents.forEach(tabContent => {
            tabContent.classList.remove('active');
        })
        tabs.forEach(tab => {
            tab.classList.remove('active');
        })
        tab.classList.add('active');
        target.classList.add('active');
    })
});

// Load Board 
// -> Details 
// -> Tracking
// -> Vehicle tracking status
// from 320px to 768px make horizontal tracking status bar
//Statusbar START
var trackingStatusBar = document.getElementsByClassName("vehicle-status-visualisation-container horizontal");
var trackingStatusBarItems = document.querySelectorAll(".vehicle-status-single-step-horizontal");
if(window.innerWidth <= 768) {
    for(let i = 0; i < trackingStatusBar.length; i++) {
        trackingStatusBar[i].classList.remove("horizontal");
    }
    for(let i = 0; i < trackingStatusBarItems.length; i++) {
        trackingStatusBarItems[i].classList.replace("vehicle-status-single-step-horizontal", "vehicle-status-single-step")
    }
}
//Statusbar END


function menuToggleClass() {
    var element = document.getElementsByClassName("nav-menu-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function paginationToggleClass() {
    var element = document.getElementsByClassName("pagination-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function tabNavigationToggleClass() {
    let allTabsButtons = document.getElementsByClassName("popup-tab-nav-item");
    let allTabs = document.querySelectorAll(".popup-tab-navigation-content");
    for (var i = 0, l = allTabsButtons.length; i < l; i++) {
        allTabsButtons[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (allTabsButtons[j] != this) {
                    allTabsButtons[j].classList.remove("active");
                    allTabs[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function toggleClass() {
    menuState.classList.toggle('compact-menu-state');
}

function userProfileDropdown() {
    var profileDetails = document.getElementsByClassName("header_profile-details-dropdown")[0];
    profileDetails.classList.toggle('active');
}

function useToggle(element) {
    var element = document.getElementsByClassName(element)[0];
    element.classList.toggle('active');
}

function openPopup(element) {
    var mainInfoPopup = document.getElementsByClassName(element)[0];
    if (mainInfoPopup.classList.contains('closed')) {
        mainInfoPopup.style.display = "flex";
        mainInfoPopup.classList.remove('closed');
        mainInfoPopup.classList.add('opened');
    } else {
        mainInfoPopup.classList.remove('opened');
        mainInfoPopup.classList.add('closed');
        setTimeout(() => {
            mainInfoPopup.style.display = "none";
        }, 100);

    }    
}

function displayFileName() {
    let fileBtn = document.getElementById('gatepass-release-for-file-uploader');
    let fileName = document.getElementsByClassName('file-uploader-placeholder')[0];

    fileBtn.addEventListener('change', function(_th) {
        if(this.files.length) 
            fileName.innerText = this.files[0].name;
        else 
            fileName.innerText = 'Choose file';
    });
};


// function clickOutside() {
//     window.addEventListener('click', function(e){   
//         if (document.getElementsByClassName('popup-content')[0].contains(e.target)){
//             console.log("yes");
//         }else{
//             console.log("no");
//         }
//     });
// }