function menuToggleClass() {
    var element = document.getElementsByClassName("nav-menu-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function paginationToggleClass() {
    var element = document.getElementsByClassName("pagination-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function toggleClass() {
    var navMenu = document.getElementsByClassName("nav-menu")[0];
    navMenu.classList.toggle('active');
}

function userProfileDropdown() {
    var profileDetails = document.getElementsByClassName("header_profile-details-dropdown")[0];
    profileDetails.classList.toggle('active');
}

function useToggle(element) {
    var element = document.getElementsByClassName(element)[0];
    element.classList.toggle('active');
}

console.log(document.getElementsByClassName("branch-single-main-info-popup")[0].classList)

function openPopup(element) {
    var mainInfoPopup = document.getElementsByClassName(element)[0];
    console.log(mainInfoPopup.classList);
    if (mainInfoPopup.classList.contains('closed')) {
        mainInfoPopup.style.display = "flex";
        mainInfoPopup.classList.remove('closed');
        mainInfoPopup.classList.add('opened');
    } else {
        mainInfoPopup.classList.remove('opened');
        mainInfoPopup.classList.add('closed');
        setTimeout(() => {
            mainInfoPopup.style.display = "none";
        }, 250);
    }
}