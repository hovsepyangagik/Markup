function menuToggleClass() {
    var element = document.getElementsByClassName("nav-menu-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function toggleClass() {
    var navMenu = document.getElementsByClassName("nav-menu")[0];
    navMenu.classList.toggle('active');
}