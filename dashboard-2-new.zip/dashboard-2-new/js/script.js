function menuToggleClass() {
    var element = document.getElementsByClassName("nav-menu-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}

function paginationToggleClass() {
    var element = document.getElementsByClassName("pagination-item");
    for (var i = 0, l = element.length; i < l; i++) {
        element[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (element[j] != this) {
                    element[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}


function tabNavigationToggleClass() {
    let allTabsButtons = document.getElementsByClassName("popup-tab-nav-item");
    let allTabs = document.querySelectorAll(".popup-tab-navigation-content");
    for (var i = 0, l = allTabsButtons.length; i < l; i++) {
        allTabsButtons[i].onclick = function() {
            for (var j = 0; j < l; j++) {
                if (allTabsButtons[j] != this) {
                    allTabsButtons[j].classList.remove("active");
                    allTabs[j].classList.remove("active");
                }
            }
            this.classList.toggle('active');
        }
    }
}


const tabs = document.querySelectorAll("[data-tab-target]")
const tabContents = document.querySelectorAll('[data-tab-content]');
tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = document.querySelector(tab.dataset.tabTarget);
        tabContents.forEach(tabContent => {
            tabContent.classList.remove('active');
        })
        tabs.forEach(tab => {
            tab.classList.remove('active');
        })
        tab.classList.add('active');
        target.classList.add('active');
    })
})


























function toggleClass() {
    var navMenu = document.getElementsByClassName("nav-menu")[0];
    navMenu.classList.toggle('active');
}

function userProfileDropdown() {
    var profileDetails = document.getElementsByClassName("header_profile-details-dropdown")[0];
    profileDetails.classList.toggle('active');
}

function useToggle(element) {
    var element = document.getElementsByClassName(element)[0];
    element.classList.toggle('active');
}

function openPopup(element) {
    var mainInfoPopup = document.getElementsByClassName(element)[0];
    if (mainInfoPopup.classList.contains('closed')) {
        mainInfoPopup.style.display = "flex";
        mainInfoPopup.classList.remove('closed');
        mainInfoPopup.classList.add('opened');
    } else {
        mainInfoPopup.classList.remove('opened');
        mainInfoPopup.classList.add('closed');
        setTimeout(() => {
            mainInfoPopup.style.display = "none";
        }, 250);
    }
}


function displayFileName() {
    let fileBtn = document.getElementById('gatepass-release-for-file-uploader');
    let fileName = document.getElementsByClassName('file-uploader-placeholder')[0];

    fileBtn.addEventListener('change', function(_th) {
        if(this.files.length) 
            fileName.innerText = this.files[0].name;
        else 
            fileName.innerText = 'Choose file';
    });
};

 