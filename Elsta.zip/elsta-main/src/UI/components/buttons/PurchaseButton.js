import '../../components-styles/buttons-styles/purchaseButton.scss'

// PurchaseButton component - fixed

function PurchaseButton() {
    return (
        <div className='purchaseButton'>
            <a href='../../../images/brackets.png'>Purchase</a>
        </div>
    )
}
export default PurchaseButton

