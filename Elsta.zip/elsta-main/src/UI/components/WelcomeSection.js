import "../components-styles/welcomeSection.scss";

function WelcomeSection() {
    return (
        <section className="welcomeSection">
            <h2>Welcome To elsta</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit 
            sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
        </section>
    )
}

export default WelcomeSection;