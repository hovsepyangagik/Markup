import '../../components-styles/shadowEffects/shadowEffect.scss';

function ShadowEffect() {
    return (
        <div className='shadow-line'>
            <div className='shadow-effect'></div>
        </div>
    )
}

export default ShadowEffect